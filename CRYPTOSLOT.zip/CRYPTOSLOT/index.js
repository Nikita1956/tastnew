const express = require("express")
const upload = require("express-fileupload")
const cors = require("cors")
const bodyParser = require("body-parser")
const { v4: uuidv4 } = require('uuid');
const fs = require("fs")
const nodemailer = require("nodemailer");
const e = require("express");

const app = express()
const PORT = process.env.PORT || 3000

var changebles = JSON.parse(fs.readFileSync("./data/changebles.json"))
var reviews = JSON.parse(fs.readFileSync("./data/reviews.json"))
var list = JSON.parse(fs.readFileSync("./data/transactions.json"))

app.use(upload())
app.use(cors())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.use(express.static("public"))

const transporter = nodemailer.createTransport({
    service: "Mail.ru",
    auth: {
        user: "cryptoslot@mail.ru",
        pass: "ED7ErFMvGgMF9cZchNwT"
    }
})
var options = {
    from: "cryptoslot@mail.ru",
    to: "cryptoslot@mail.ru",
    subject: "Новый заказ!"
}


function render(res, file) {
    res.sendFile(__dirname + "/" + file)
}
var giveCrypto = { BTC: 0, ETH: 1, XRP: 2, ADA: 3, BNB: 4, SOL: 5, DOGE: 6, PAYEER: 7 }
var getCrypto = { BTC: 0, ETH: 1, XRP: 2, ADA: 3, BNB: 4, SOL: 5, DOGE: 6, USD: 7, PAYEER: 8 }

function tCrypto(num) {
    let result
    Object.keys(getCrypto).map(i => {
        if (getCrypto[i] == Number(num)) {
            result = i
        }
    })
    return result
}

function updatelist(data) {
    list = JSON.parse(fs.readFileSync("./data/transactions.json"))
    if (data != undefined) {
        list.push(data)
        fs.writeFileSync("./data/transactions.json", JSON.stringify(data))
        updatelist()
    }
}
function updatechangebles(data) {
    changebles = JSON.parse(fs.readFileSync("./data/changebles.json"))
    if (data != undefined) {
        fs.writeFileSync("./data/changebles.json", JSON.stringify(data))
        updatechangebles()
    }
}
function updatereviews(data) {
    reviews = JSON.parse(fs.readFileSync("./data/reviews.json"))
    if (data != undefined) {
        fs.writeFileSync("./data/reviews.json", JSON.stringify(data))
        updatereviews()
    }
}
function vCrypto(num) {
    let result
    Object.keys(giveCrypto).map(i => {
        if (giveCrypto[i] == Number(num)) {
            result = i
        }
    })
    return result
}

app.get("/", (req, res) => {
    render(res, "index.html")
})
app.get("/privacy", (req, res) => {
    render(res, "privacy.html")
})
app.get("/request/:transaction_id", (req, res) => {
    let status
    let data
    list.map(i => {
        if (i.transaction_id == req.params.transaction_id) {
            data = i
            status = 200
        }
    })
    if (data != undefined) {
        res.status(status).send(`
        <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Быстрый обмен криптовалют | Bitcoin | Ethereum | Ripple</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--[if IE]><link rel="shortcut icon" href="https://i.1.creatium.io/0d/de/38/4fe4bf8fedf0d495a9106e9580b8a387e1/32x32/favicon2_size.png"><![endif]-->
    <link rel="apple-touch-icon-precomposed"
        href="0d/de/38/4fe4bf8fedf0d495a9106e9580b8a387e1/180x180/favicon2_size.png">
    <link rel="icon" href="0d/de/38/4fe4bf8fedf0d495a9106e9580b8a387e1/196x196/favicon2_size.png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial;
            color: white;
            transition: .2s;
        }

        body {
            background-color: rgb(31, 31, 38);
        }

        .card {
            background-color: rgb(36, 37, 49);
            border-radius: 55px;
            box-shadow: 0px 2px 50px -4px rgb(0 0 0 / 65%);
            padding: 55px;
            margin: 20px auto 0;
            width: 540px;
        }

        .container {
            flex-wrap: wrap;
            max-width: 1140px;
            padding: 0 20px;
            column-gap: 20px;
            margin: auto;
            display: flex;
            justify-content: space-between;

        }

        .card-title {
            text-align: center;
            padding-bottom: 10px;
            border-bottom: 1px solid white;
            font-size: 30px;
            font-weight: 500;
        }

        .card-body {
            padding: 20px 0;
            display: flex;
            flex-direction: column;
            gap: 10px;
            border-bottom: 1px solid white;
        }

        .whattowhat,
        .wallet {
            text-align: center;
            position: relative;
            font-size: 15px;
            display: flex;
        }

        .whattowhat div {
            width: 50%;
        }

        .wallet {
            justify-content: center;
        }

        span {
            color: rgb(149, 136, 223);
        }

        .ins div:not(:last-child) {
            margin-bottom: 10px;
        }
        a {
            text-decoration: none;
            width: fit-content;
            display: block;
            background: linear-gradient(180deg, rgb(172, 156, 255), rgb(147, 125, 255));
            color: rgb(255, 255, 255);
            border: none;
            box-shadow: 0px 0px 29px 4px rgba(155, 129, 247, 0.56);
            border-radius: 50px;
            padding: 15px 20px;
            font-weight: 600;
            font-size: 17px;
            margin: 20px auto 0;
            cursor: pointer;
        }
        a:hover{
            scale: 1.2;
        }
        a:active{
            scale: 0.8;
        }
        footer{
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100px;
            margin-top: 20px;
            font-size: 14px;
            line-height: 1.6;
            opacity: 0.31;
        }

        @media (max-width: 600px) {
            .whattowhat {
                flex-direction: column;
                text-align: left;
            }

            .wallet {
                justify-content: unset;
            }

            .card-body {
                gap: unset;
            }


        }
    </style>
</head>

<body>
    <div class="container">
        <div class="card">
            <div class="card-title">Заказ</div>
            <div class="card-body">
                <div class="whattowhat">
                    <div>
                        <span>Вы даёте:</span> ${data.data.countofcrypto} <span>${vCrypto(data.data.give)}</span>
                    </div>
                    <div>
                        <span>Получаете:</span> ${data.data.claimnum} <span>${tCrypto(data.data.get)}</span>
                    </div>
                </div>
                <div class="wallet">
                    <span>На счёт:</span> ${data.data.wallet.requisit}
                </div>
                <div class="whattowhat">
                    <div>
                        <span>Эквивалент в USD:</span> ${data.data.ekvival}
                    </div>
                    <div>
                        <span>Итого в USD:</span> ${data.data.itogo}
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-title">Контакты</div>
            <div class="card-body">
                <div class="whattowhat">
                    <div>
                        <span>Имя:</span> ${data.data.name}
                    </div>
                    <div>
                        <span>EMAIL:</span> ${data.data.email}
                    </div>
                </div>
                <div class="wallet">
                    <span>Номер телефона:</span> ${data.data.phone}
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-title">Инструкция</div>
            <div class="card-body">
                <div class="ins">
                    <div>
                        <span>Шаг 1:</span> Вы отправляете ${data.data.countofcrypto} <span>${vCrypto(data.data.give)}</span> на наш счёт:
                        <span>${changebles["wallet"+vCrypto(data.data.give)]}</span>
                    </div>
                    <div>
                        <span>Шаг 2:</span> Нажимаете на кнопку <span>"Я оплатил!"</span> ниже.
                    </div>
                    <div>
                        <span>Шаг 3:</span> Ожидаете выполнение заказа.
                    </div>
                    <div style="font-style: italic; text-align: right;">
                        <span>*Счёт действителен в течении 5 минут!*</span>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <a href="/succesfull/${data.transaction_id}">Я оплатил!</a>
    <footer>
        <div>
            ©all rights reserved CryptoLot 2022-2023
        </div>
        <div>
            Made with ❤ by human
        </div>
    </footer>
</body>

</html>
        `)
    } else {
        res.status(404).send("Транзакция не найдена или уже была инициализирована!")
    }
})

app.get("/succesfull/:transaction_id", (req, res) => {
    if (list.length != 0) {
        for (let i = 0; i < list.length; i++) {
            if (list[i].transaction_id == req.params.transaction_id) {
                options.html = `<style>address{width:fit-content !important;}</style>
                <p>
                    <address style="width: fit-content;">Имя:</address> ${list[i].data.name} <br>
                </p>
                <p>
                    <address style="width: fit-content;">Почта:</address> ${list[i].data.email} <br>
                </p>
                <p>
                    <address style="width: fit-content;">Номер:</address> ${list[i].data.phone} <br>
                </p>
                <p>
                    <address style="width: fit-content;">Отдаёт:</address> ${list[i].data.countofcrypto} ${vCrypto(list[i].data.give)}<br>
                </p>
                <p>
                    <address style="width: fit-content;">Получает:</address> ${list[i].data.claimnum} ${tCrypto(list[i].data.get)}<br>
                </p>
                <p>
                    <address style="width: fit-content;">На:</address> ${list[i].data.wallet.requisit} <br>
                </p>
                <p>
                    <address style="width: fit-content;">Эквивалент:</address> ${list[i].data.ekvival} <br>
                </p>
                <p>
                    <address style="width: fit-content;">Итого:</address> ${list[i].data.itogo} <br>
                </p>
                <p>
                    <address style="width: fit-content;">Время:</address> ${list[i].time} по GMT+0 <br>
                </p>
                `
                transporter.sendMail(options, (error, info) => {
                    if (error) { console.log(error) }
                    else { console.log("new") }
                })
                list.splice(i, 1)
                updatelist(list)
                res.send(`
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <title>Быстрый обмен криптовалют | Bitcoin | Ethereum | Ripple</title>
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <!--[if IE]><link rel="shortcut icon" href="https://i.1.creatium.io/0d/de/38/4fe4bf8fedf0d495a9106e9580b8a387e1/32x32/favicon2_size.png"><![endif]-->
                    <link rel="apple-touch-icon-precomposed"
                        href="0d/de/38/4fe4bf8fedf0d495a9106e9580b8a387e1/180x180/favicon2_size.png">
                    <link rel="icon" href="0d/de/38/4fe4bf8fedf0d495a9106e9580b8a387e1/196x196/favicon2_size.png">
                    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial;
            color: white;
            transition: .2s;
        }
        a {
            text-decoration: none;
            width: fit-content;
            display: block;
            background: linear-gradient(180deg, rgb(172, 156, 255), rgb(147, 125, 255));
            color: rgb(255, 255, 255);
            border: none;
            box-shadow: 0px 0px 29px 4px rgba(155, 129, 247, 0.56);
            border-radius: 50px;
            padding: 15px 20px;
            font-weight: 600;
            font-size: 17px;
            margin: 20px auto 0;
            cursor: pointer;
        }
        a:hover{
            scale: 1.2;
        }
        a:active{
            scale: 0.8;
        }
        body {
            background-color: rgb(31, 31, 38);
            width: 100vw;
            height: 100vh;
            display:flex;
            align-items:center;
            justify-content: center;
            flex-direction: column;
        }
        
        </style>
                </head>
                <body>
                    <h1>Спасибо за заказ!</h1>
                    <a href="/">На главную</a>
                    <script>localstorage.setItem("bought", true)</script>
                </body>
                </html>
                `)
            } else if (i == list.length - 1) {
                res.status(404).send("Транзакция не найдена или уже была инициализирована!")
            }
        }
    } else {
        res.status(404).send("Транзакция не найдена или уже была инициализирована!")

    }
})
app.post("/post", (req, res) => {
    let data = req.body
    let wallet
    if (tCrypto(data.get) == "PAYEER") {
        wallet = { method: "PAYEER", requisit: data.payeerwallet }
    } else if (tCrypto(data.get) == "USD") {
        wallet = { method: "USD", requisit: data.numberofbankcard }
    } else {
        wallet = { method: tCrypto(data.get), requisit: data.cryptowallet }
    }
    delete data.payeerwallet
    delete data.cryptowallet
    delete data.numberofbankcard
    data.wallet = wallet
    let transaction = { transaction_id: uuidv4(), data: data, time: new Date().toJSON().slice(0, 19) }
    list.push(transaction)
    res.status(302).send(transaction.transaction_id)
    updatelist(list)
})
app.get("/login", (req, res) => {
    res.sendFile(__dirname + "/login.html")
})
app.get("/admin", (req, res) => {
    let logins = JSON.parse(fs.readFileSync("./data/logins.json"))
    if (logins.login == req.query.login && logins.pass == req.query.pass) {
        res.sendFile(__dirname + "/admin.html")
    } else {
        res.redirect("/login")
    }
})
app.get("/changebles", (req, res) => {
    res.json(changebles)
})
app.post("/changebles", (req, res) => {
    let data = req.body
    let logins = JSON.parse(fs.readFileSync("./data/logins.json"))
    if (logins.login == data.login && logins.pass == data.pass) {
        delete data.login
        delete data.pass
        updatechangebles(data)
        res.sendStatus(200)
    } else {
        res.sendStatus(403)
    }
})
app.get("/reviews", (req, res) => {
    res.json(reviews)
})
app.post("/reviews", (req, res) => {
    req.body.id = reviews.length
    reviews.push(req.body)
    updatereviews(reviews)
    res.sendStatus(200)
})
function reid(res) {
    for (let i = 0; i < reviews.length; i++) {
        reviews[i].id = i
    }
    updatereviews(reviews)
    res.sendStatus(200)
}
app.post("/dreview", (req, res) => {
    let data = req.body
    let logins = JSON.parse(fs.readFileSync("./data/logins.json"))
    if(logins.login == data.login && logins.pass == data.pass){
        let j = false
        for (let i = 0; i < reviews.length; i++) {
            if (reviews[i].id == req.body.id) {
                reviews.splice(i, 1)
                j = true
            }
        }
        if (j) {
            reid(res)
        }
    }else{
        res.sendStatus(403)
    }
})
app.get("*", (req, res) => {
    res.status(404).send("Страница не найдена!")
})
app.listen(PORT, (e) => {
    console.log("Server started!")
})