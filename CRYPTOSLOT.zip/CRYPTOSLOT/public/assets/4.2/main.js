(function () {
    /**
     * Корректировка округления десятичных дробей.
     *
     * @param {String}  type  Тип корректировки.
     * @param {Number}  value Число.
     * @param {Integer} exp   Показатель степени (десятичный логарифм основания корректировки).
     * @returns {Number} Скорректированное значение.
     */
    function decimalAdjust(type, value, exp) {
        // Если степень не определена, либо равна нулю...
        if (typeof exp === 'undefined' || +exp === 0) {
            return Math[type](value);
        }
        value = +value;
        exp = +exp;
        // Если значение не является числом, либо степень не является целым числом...
        if (isNaN(value) || !(typeof exp === 'number' && exp % 1 === 0)) {
            return NaN;
        }
        // Сдвиг разрядов
        value = value.toString().split('e');
        value = Math[type](+(value[0] + 'e' + (value[1] ? (+value[1] - exp) : -exp)));
        // Обратный сдвиг
        value = value.toString().split('e');
        return +(value[0] + 'e' + (value[1] ? (+value[1] + exp) : exp));
    }

    // Десятичное округление к ближайшему
    if (!Math.round10) {
        Math.round10 = function (value, exp) {
            return decimalAdjust('round', value, exp);
        };
    }
    // Десятичное округление вниз
    if (!Math.floor10) {
        Math.floor10 = function (value, exp) {
            return decimalAdjust('floor', value, exp);
        };
    }
    // Десятичное округление вверх
    if (!Math.ceil10) {
        Math.ceil10 = function (value, exp) {
            return decimalAdjust('ceil', value, exp);
        };
    }
})();
var giveCrypto = { BTC: 0, ETH: 1, XRP: 2, ADA: 3, BNB: 4, SOL: 5, DOGE: 6, PAYEER: 7 }
var getCrypto = { BTC: 0, ETH: 1, XRP: 2, ADA: 3, BNB: 4, SOL: 5, DOGE: 6, USD: 7, PAYEER: 8 }
function updatecrypto(classname, newdata) {
    let list = document.querySelectorAll(".binance" + classname)
    for (let i = 0; i < list.length; i++) {
        list[i].innerHTML = `${Math.round10(newdata, -2)} $`
    }
}
function tCrypto(num) {
    let result
    Object.keys(getCrypto).map(i => {
        if (getCrypto[i] == Number(num)) {
            result = i
        }
    })
    return result
}

function vCrypto(num) {
    let result
    Object.keys(giveCrypto).map(i => {
        if (giveCrypto[i] == Number(num)) {
            result = i
        }
    })
    return result
}
var givesel = document.querySelector(".givesel")
var claimse = document.querySelector(".claimse")
var givenum = document.querySelector("input[type='number']")
givesel.addEventListener("change", e => {
    calculate(givesel.value, claimse.value)
    let giveicon = document.querySelectorAll(".giveicon")
    let toblock
    for (let i = 0; i < giveicon.length; i++) {
        giveicon[i].style = ""
        String(i) == givesel.value ? toblock = i : ""
    }
    if (toblock !== undefined) {
        giveicon[toblock].style = "display: block;"
    }
})
claimse.addEventListener("change", e => {
    let geticon = document.querySelectorAll(".geticon")
    let toblock
    for (let i = 0; i < geticon.length; i++) {
        geticon[i].style = ""
        String(i) == claimse.value ? toblock = i : ""
    }
    if (toblock !== undefined) {
        geticon[toblock].style = "display: block;"
    }
    calculate(givesel.value, claimse.value)
})
givenum.addEventListener("keyup", e => {

    calculate(givesel.value, claimse.value)
})
givenum.addEventListener("change", e => {

    calculate(givesel.value, claimse.value)
})

function calculate(value, value2) {
    if (givesel.value == "7" && claimse.value != "" && Number(claimse.value) < 7) {
        document.querySelector(".claimnum").innerHTML = ((Number(givenum.value)) / window["usd2" + tCrypto(value2).toLowerCase()]) + ((Number(givenum.value)) / window["usd2" + tCrypto(value2).toLowerCase()]) * KOEFCLAIM
    }
    else if (givesel.value != "" && claimse.value != "" && Number(claimse.value) < 7) {
        document.querySelector(".claimnum").innerHTML = ((window["usd2" + vCrypto(value).toLowerCase()] * Number(givenum.value)) / window["usd2" + tCrypto(value2).toLowerCase()]) + ((window["usd2" + vCrypto(value).toLowerCase()] * Number(givenum.value)) / window["usd2" + tCrypto(value2).toLowerCase()]) * KOEFCLAIM
        // 
    } else if (givesel.value != "" && claimse.value != "" && Number(claimse.value) >= 7) {
        document.querySelector(".claimnum").innerHTML = (window["usd2" + vCrypto(value).toLowerCase()] * Number(givenum.value)) + (window["usd2" + vCrypto(value).toLowerCase()] * Number(givenum.value)) * KOEFCLAIM
    } else {
        document.querySelector(".claimnum").innerHTML = "0"
    }
    if (value == "0") {
        document.querySelector(".ekvival").innerHTML = Math.round10(window.usd2btc * Number(givenum.value), -4)
        document.querySelector(".itogo").innerHTML = itogo(window.usd2btc * Number(givenum.value))
    } else if (value == "1") {
        document.querySelector(".ekvival").innerHTML = Math.round10(window.usd2eth * Number(givenum.value), -4)
        document.querySelector(".itogo").innerHTML = itogo(window.usd2eth * Number(givenum.value))
    } else if (value == "2") {
        document.querySelector(".ekvival").innerHTML = Math.round10(window.usd2xrp * Number(givenum.value), -4)
        document.querySelector(".itogo").innerHTML = itogo(window.usd2xrp * Number(givenum.value))
    } else if (value == "3") {
        document.querySelector(".ekvival").innerHTML = Math.round10(window.usd2ada * Number(givenum.value), -4)
        document.querySelector(".itogo").innerHTML = itogo(window.usd2ada * Number(givenum.value))
    } else if (value == "4") {
        document.querySelector(".ekvival").innerHTML = Math.round10(window.usd2bnb * Number(givenum.value), -4)
        document.querySelector(".itogo").innerHTML = itogo(window.usd2bnb * Number(givenum.value))
    } else if (value == "5") {
        document.querySelector(".ekvival").innerHTML = Math.round10(window.usd2sol * Number(givenum.value), -4)
        document.querySelector(".itogo").innerHTML = itogo(window.usd2sol * Number(givenum.value))
    } else if (value == "6") {
        document.querySelector(".ekvival").innerHTML = Math.round10(window.usd2doge * Number(givenum.value), -4)
        document.querySelector(".itogo").innerHTML = itogo(window.usd2doge * Number(givenum.value))
    } else if (value == "") {
        document.querySelector(".ekvival").innerHTML = "0"
    }
}
function itogo(value) {
    return Math.round10(value + (value * KOEF), -4)
}
function getreview() {
    $.get("/reviews").then(function (data) {
        document.querySelector(".reviews").innerHTML = ""
        data.map(i => {
            document.querySelector(".reviews").innerHTML += `
            <div class="review">
                <div class="review-text">${i.text}</div>
                <div class="review-rate">${i.rate}/10</div>
            </div>
            `
        })
    })
}
function sendreview() {
    $.post("/reviews", { "text": document.getElementById("review-textarea").value, "rate": Number(document.getElementById("textarea-rateinput").value) }).then(function (data) {
        getreview()
    })
    document.querySelector(".sendreview").style = "display:none"
    document.querySelector("#review-textarea").value = ""
    document.querySelector("#textarea-rateinput").value = ""
}
var PERCENT
var PERCENTCLAIM
var KOEFCLAIM
var KOEF
var MINIMUM
var MAXIMUM
$.get("/changebles").then(function (data) {
    MINIMUM = data.minimum
    MAXIMUM = data.maximum
    PERCENT = data.percent
    PERCENTCLAIM = data.percentclaim
    KOEFCLAIM = Number(PERCENTCLAIM / 100)
    KOEF = Number(PERCENT / 100)
    document.querySelector(".minimum").innerHTML = MINIMUM
    document.querySelector(".maximum").innerHTML = MAXIMUM
    document.querySelector(".support-icon").href = data.telegram
})



function updateallcrypto() {
    $.get("/changebles").then(function (data) {
        MINIMUM = data.minimum
        MAXIMUM = data.maximum
        PERCENT = data.percent
        PERCENTCLAIM = data.percentclaim
        KOEFCLAIM = Number(PERCENTCLAIM / 100)
        KOEF = Number(PERCENT / 100)
        document.querySelector(".minimum").innerHTML = MINIMUM
        document.querySelector(".maximum").innerHTML = MAXIMUM
        document.querySelector(".support-icon").href = data.telegram
    })


    $.get('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT').then(function (data) {

        window.usd2btc = Math.round10(data.price, -2);
        updatecrypto("btc", Math.round10(data.price, -2))
        calculate(givesel.value, claimse.value)


    })
    $.get('https://api.binance.com/api/v3/ticker/price?symbol=ETHUSDT').then(function (data) {

        window.usd2eth = Math.round10(data.price, -2);
        updatecrypto("eth", Math.round10(data.price, -2))
        calculate(givesel.value, claimse.value)


    })

    $.get('https://api.binance.com/api/v3/ticker/price?symbol=XRPUSDT').then(function (data) {

        window.usd2xrp = Math.round10(data.price, -2);
        updatecrypto("xrp", Math.round10(data.price, -2))
        calculate(givesel.value, claimse.value)


    })
    $.get('https://api.binance.com/api/v3/ticker/price?symbol=BNBUSDT').then(function (data) {

        window.usd2bnb = Math.round10(data.price, -2);
        updatecrypto("bnb", Math.round10(data.price, -2))
        calculate(givesel.value, claimse.value)


    })
    $.get('https://api.binance.com/api/v3/ticker/price?symbol=SOLUSDT').then(function (data) {

        window.usd2sol = Math.round10(data.price, -2);
        updatecrypto("sol", Math.round10(data.price, -2))
        calculate(givesel.value, claimse.value)


    })
    $.get('https://api.binance.com/api/v3/ticker/price?symbol=ADAUSDT').then(function (data) {

        window.usd2ada = Math.round10(data.price, -2);
        calculate(givesel.value, claimse.value)


    })
    $.get('https://api.binance.com/api/v3/ticker/price?symbol=DOGEUSDT').then(function (data) {

        window.usd2doge = Math.round10(data.price, -2);
        calculate(givesel.value, claimse.value)


    })
    calculate(givesel.value, claimse.value)
    MINUT = "10"
    SECOND = "00"
    document.querySelector(".timeout").innerHTML = `${MINUT}:${SECOND}`
}
setInterval(() => {
    if (SECOND == "00") {
        SECOND = "60"
        MINUT = String(Number(MINUT) - 1)
    }
    SECOND = String(Number(SECOND) - 1)
    if (SECOND.length == 1) {
        SECOND = "0" + SECOND
    }
    if (MINUT.length == 1) {
        MINUT = "0" + MINUT
    }
    document.querySelector(".timeout").innerHTML = `${MINUT}:${SECOND}`
    if (MINUT == "00" && SECOND == "00") {
        updateallcrypto()
    }
}, 1000);

document.querySelector("form").addEventListener("submit", (e) => {
    e.preventDefault()
    if (givesel.value != "" && document.querySelectorAll(".adad input")[lastopen].value != "" && Number(givenum.value) > 0 && claimse.value != "" && document.querySelector("input[name='name']").value.length > 0 && document.querySelector("input[name='email']").value.length > 0 && document.querySelector("input[name='phone']").value.length > 0) {
        if (Number(document.querySelector(".itogo").innerHTML) >= MINIMUM && Number(document.querySelector(".itogo").innerHTML) <= MAXIMUM) {
            let data = new FormData(document.querySelector("form"))
            data.append("ekvival", document.querySelector(".ekvival").innerHTML)
            data.append("itogo", document.querySelector(".itogo").innerHTML)
            data.append("claimnum", document.querySelector(".claimnum").innerHTML)
            const request = new XMLHttpRequest()
            request.open('post', '/post')
            request.send(data)
            request.onload = () => {
                window.location = "/request/" + request.response
            }
        } else {
            alert("Итоги не соответствуют min или max")
        }
    } else {
        alert("Не все поля заполнены")
    }
})

document.getElementById("textarea-submit").addEventListener("click", e => {
    sendreview()
})
getreview()

updateallcrypto()
